function About() {
  return (
    <div>
      <h1 className="text-6xl mb-4">Github Finder</h1>
      <p className="mb-4 text-2xl font-light">
        A React app to search GitHub profiles and profile details.
        I got the idea for this react app from a well-known YouTuber who deals with programming.
      </p>
      <p className="text-lg text-gray-400">
        Coded By:{' '}
        <a
          className="text-white"
          href="https://github.com/kris015"
          target="_blank"
          rel="noreferrer"
        >
          Kristijan Cvetinovic
        </a>
      </p>
    </div>
  );
}

export default About;
