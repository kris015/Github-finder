Hi!

This is a React app to search GitHub profiles and see profile details. I got the idea for this react app from a well-known YouTuber who deals with programming.